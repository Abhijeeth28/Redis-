module.exports = {
  // TCP Server Configuration
  tcp: {
    port: 9736,
    host: '0.0.0.0',
    maxConnections: 100,
  },

  // Redis Configuration
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || undefined,
    db: process.env.REDIS_DB || 0,
    
    // Connection Pool Configuration
    pool: {
      min: 5,                // Minimum connections to maintain
      max: 50,               // Maximum connections allowed
      acquireTimeout: 5000,  // Wait 5s for connection before error (ms)
      idleTimeout: 30000,    // Close idle connections after 30s (ms)
      evictionRunInterval: 60000, // Check for idle connections every 60s (ms)
    },
    
    retryStrategy: (times) => {
      const delay = Math.min(times * 50, 2000);
      return delay;
    },
    maxRetriesPerRequest: 3,
  },

  // Logging Configuration
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    directory: 'logs',
    maxFiles: 5,
    maxSize: '10m',
  },

  // Rate Limiting Configuration
  rateLimiting: {
    enabled: true,
    default: {
      limit: 100,        // requests per window
      windowSeconds: 60, // time window in seconds
    },
    redisKeyPrefix: 'ratelimit:client:', // Key pattern: ratelimit:client:{clientId}
  },

  // Shutdown Configuration
  shutdown: {
    gracePeriodMs: 10000, // 10 seconds to wait for active commands
  },
};
