#!/bin/bash

echo "=========================================="
echo "Testing Rate Limiter with Sliding Window"
echo "=========================================="
echo ""

# Test 1: Check default rate limit
echo "Test 1: Check default rate limit"
echo "CHECKRATE" | nc localhost 9736
echo ""

# Test 2: Set custom rate limit (5 requests per 10 seconds)
echo "Test 2: Set rate limit to 5 requests per 10 seconds"
(echo "RLCONFIG 5 10"; sleep 0.1) | nc localhost 9736
echo ""
STATS
# Test 3: Send 3 PING requests (should all succeed)
echo "Test 3: Send 3 PING requests (should succeed)"
for i in {1..3}; do
  echo "  Request $i:"
  echo "PING" | nc localhost 9736
done
echo ""

# Test 4: Check status
echo "Test 4: Check rate limit status"
echo "CHECKRATE" | nc localhost 9736
echo ""

# Test 5: Send 3 more PING requests (request 6 should fail, we already sent 3 + 1 CHECKRATE = 4)
echo "Test 5: Send 3 more PING requests (last ones should fail due to limit)"
for i in {4..6}; do
  echo "  Request $i:"
  echo "PING" | nc localhost 9736
done
echo ""

# Test 6: Check status after rate limit
echo "Test 6: Check rate limit status after exceeding"
echo "CHECKRATE" | nc localhost 9736
echo ""

echo "=========================================="
echo "Test Complete!"
echo "=========================================="
