const config = require('./config');
const logger = require('./src/logger');
const redisClient = require('./src/redis-client');
const TCPServer = require('./src/server');

// Create server instance
const server = new TCPServer();

/**
 * Graceful shutdown handler
 */
async function gracefulShutdown(signal) {
  logger.serverEvent(`Received ${signal}, starting graceful shutdown...`);

  try {
    // Shutdown TCP server first
    await server.shutdown();
    logger.serverEvent('TCP server shutdown complete');

    // Shutdown connection pool
    await redisClient.shutdownPool();
    logger.serverEvent('Redis pool shut down');

    logger.serverEvent('Shutdown complete');
    process.exit(0);
  } catch (error) {
    logger.error(`Error during shutdown: ${error.message}`);
    process.exit(1);
  }
}

/**
 * Main application startup
 */
async function main() {
  try {
    logger.serverEvent('='.repeat(50));
    logger.serverEvent('Redis TCP Server Starting...');
    logger.serverEvent('='.repeat(50));

    // Validate Redis connectivity (doesn't create pool yet)
    logger.serverEvent('Validating Redis connectivity...');
    await redisClient.validateConnectivity();
    logger.serverEvent(`Redis available at ${config.redis.host}:${config.redis.port}`);
    logger.serverEvent('Connection pool will be initialized on first command');

    // Start TCP server
    logger.serverEvent('Starting TCP server...');
    await server.start();
    logger.serverEvent(`TCP server listening on ${config.tcp.host}:${config.tcp.port}`);

    logger.serverEvent('='.repeat(50));
    logger.serverEvent('Server is ready to accept connections');
    logger.serverEvent('='.repeat(50));

    // Register shutdown handlers
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    // Handle uncaught errors
    process.on('uncaughtException', (error) => {
      logger.error(`Uncaught Exception: ${error.message}`);
      logger.error(error.stack);
      gracefulShutdown('uncaughtException');
    });

    process.on('unhandledRejection', (reason, promise) => {
      logger.error(`Unhandled Rejection at: ${promise}, reason: ${reason}`);
      gracefulShutdown('unhandledRejection');
    });

  } catch (error) {
    logger.error(`Failed to start server: ${error.message}`);
    logger.error(error.stack);
    process.exit(1);
  }
}

// Start the application
main();
