const net = require('net');

async function testDefaultRateLimiter() {
  console.log('========================================');
  console.log('Testing Default Rate Limiter');
  console.log('========================================\n');

  const client = net.createConnection({ port: 9736, host: 'localhost' });
  
  let buffer = '';
  const responses = [];
  
  client.on('data', (data) => {
    buffer += data.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop();
    
    for (const line of lines) {
      if (line.trim()) {
        responses.push(line.trim());
      }
    }
  });

  await new Promise(resolve => client.once('connect', resolve));
  console.log('Connected to server\n');

  async function sendAndWait(cmd, label) {
    const before = responses.length;
    client.write(cmd + '\n');
    console.log(`${label}: ${cmd}`);
    
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (responses.length > before) {
          clearInterval(check);
          console.log(`  → ${responses[responses.length - 1]}\n`);
          resolve();
        }
      }, 50);
    });
  }

  // Test 1: Set DEFAULT rate limit (no identifier) - 2 requests per 5 seconds
  console.log('=== Test 1: Set Default Rate Limit ===');
  await sendAndWait('RLCONFIG 2 5', 'Set default limit');

  // Test 2: Check status for identifier 1234 (should use default)
  console.log('=== Test 2: Check Identifier 1234 (Should Use Default) ===');
  await sendAndWait('CHECKRATE 1234', 'Check 1234 status');
  await sendAndWait('RLSTATS 1234', 'Check 1234 remaining');

  // Test 3: Make requests to 1234 (should be limited to 2)
  console.log('=== Test 3: Make Requests to 1234 ===');
  await sendAndWait('RATELIMIT 1234 action', 'Request 1 to 1234');
  await sendAndWait('RLSTATS 1234', 'Remaining after request 1');
  
  await sendAndWait('RATELIMIT 1234 action', 'Request 2 to 1234');
  await sendAndWait('RLSTATS 1234', 'Remaining after request 2');
  
  await sendAndWait('RATELIMIT 1234 action', 'Request 3 to 1234 (SHOULD BE THROTTLED)');
  await sendAndWait('RLSTATS 1234', 'Remaining after throttle');
  
  await sendAndWait('RATELIMIT 1234 action', 'Request 4 to 1234 (SHOULD BE THROTTLED)');

  // Test 4: Different identifier should also use default
  console.log('\n=== Test 4: Different Identifier (Should Also Use Default) ===');
  await sendAndWait('RLSTATS 5678', 'Check 5678 remaining');
  await sendAndWait('RATELIMIT 5678 login', 'Request 1 to 5678');
  await sendAndWait('RLSTATS 5678', 'Remaining after request 1');
  await sendAndWait('RATELIMIT 5678 login', 'Request 2 to 5678');
  await sendAndWait('RLSTATS 5678', 'Remaining after request 2');
  await sendAndWait('RATELIMIT 5678 login', 'Request 3 to 5678 (SHOULD BE THROTTLED)');

  // Test 5: Set specific limit for one identifier
  console.log('\n=== Test 5: Override Default for Specific Identifier ===');
  await sendAndWait('RLCONFIG 10 5 user999', 'Set custom limit for user999');
  await sendAndWait('RLSTATS user999', 'Check user999 remaining');
  await sendAndWait('RATELIMIT user999 order', 'Request to user999');
  await sendAndWait('RLSTATS user999', 'user999 remaining after request');

  console.log('\n========================================');
  console.log('Summary of All Responses:');
  console.log('========================================');
  responses.forEach((r, i) => console.log(`${(i + 1).toString().padStart(2)}. ${r}`));
  console.log('========================================');

  client.end();
  
  setTimeout(() => {
    console.log('\n✅ Test Complete!');
    process.exit(0);
  }, 500);
}

testDefaultRateLimiter().catch(console.error);
