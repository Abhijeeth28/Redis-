const net = require('net');

async function testRateLimiter() {
  console.log('========================================');
  console.log('Testing Rate Limiter with Sliding Window');
  console.log('========================================\n');

  // Test 1: Set rate limit to 3 requests per 10 seconds
  console.log('Test 1: Setting rate limit to 3 requests per 10 seconds');
  await sendCommand('RLCONFIG 3 10');
  await sleep(200);

  // Test 2: Send 3 requests (should all succeed)
  console.log('\nTest 2: Sending 3 PING requests (should all succeed)');
  for (let i = 1; i <= 3; i++) {
    console.log(`  Request ${i}:`);
    await sendCommand('PING');
  }

  // Test 3: Check status
  console.log('\nTest 3: Checking rate limit status');
  await sendCommand('CHECKRATE');

  // Test 4: Send 2 more requests (should be rate limited)
  console.log('\nTest 4: Sending 2 more PING requests (should be rate limited)');
  for (let i = 4; i <= 5; i++) {
    console.log(`  Request ${i}:`);
    await sendCommand('PING');
  }

  // Test 5: Wait for window to pass
  console.log('\nTest 5: Waiting 11 seconds for rate limit window to reset...');
  await sleep(11000);

  // Test 6: Send request after window (should succeed)
  console.log('\nTest 6: Sending PING after window reset (should succeed)');
  await sendCommand('PING');

  console.log('\n========================================');
  console.log('Test Complete!');
  console.log('========================================');
}

function sendCommand(command) {
  return new Promise((resolve) => {
    const client = net.createConnection({ port: 9736, host: 'localhost' }, () => {
      client.write(command + '\n');
    });

    let response = '';
    client.on('data', (data) => {
      response += data.toString();
      if (response.includes('\n')) {
        console.log(`    Response: ${response.trim()}`);
        client.end();
      }
    });

    client.on('end', () => {
      resolve();
    });

    client.on('error', (err) => {
      console.log(`    Error: ${err.message}`);
      resolve();
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

testRateLimiter().catch(console.error);
