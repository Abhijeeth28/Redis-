const net = require('net');

async function testNewRateLimiter() {
  console.log('========================================');
  console.log('Testing New Rate Limiter Design');
  console.log('========================================\n');

  const client = net.createConnection({ port: 9736, host: 'localhost' });
  
  let buffer = '';
  const responses = [];
  
  client.on('data', (data) => {
    buffer += data.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop();
    
    for (const line of lines) {
      if (line.trim()) {
        responses.push(line.trim());
      }
    }
  });

  await new Promise(resolve => client.once('connect', resolve));
  console.log('Connected to server\n');

  async function sendAndWait(cmd, label) {
    const before = responses.length;
    client.write(cmd + '\n');
    console.log(`${label}: ${cmd}`);
    
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (responses.length > before) {
          clearInterval(check);
          console.log(`  → ${responses[responses.length - 1]}\n`);
          resolve();
        }
      }, 50);
    });
  }

  // Test 1: Configure rate limit for user123 - 3 requests per 10 seconds
  console.log('=== Test 1: Configure Rate Limit ===');
  await sendAndWait('RLCONFIG 3 10 user123', 'Set limit for user123');

  // Test 2: Check configuration
  console.log('=== Test 2: Check Configuration ===');
  await sendAndWait('CHECKRATE user123', 'Check rate limit status');

  // Test 3: Get initial stats
  console.log('=== Test 3: Check Initial Stats ===');
  await sendAndWait('RLSTATS user123', 'Get remaining count');

  // Test 4: Make RATELIMIT requests (should get ALLOWED)
  console.log('=== Test 4: Make Rate-Limited Requests (Should Get ALLOWED) ===');
  await sendAndWait('RATELIMIT user123 login', 'Request 1');
  await sendAndWait('RLSTATS user123', 'Check remaining');
  
  await sendAndWait('RATELIMIT user123 login', 'Request 2');
  await sendAndWait('RLSTATS user123', 'Check remaining');
  
  await sendAndWait('RATELIMIT user123 login', 'Request 3');
  await sendAndWait('RLSTATS user123', 'Check remaining');

  // Test 5: Exceed limit (should get THROTTLED)
  console.log('=== Test 5: Exceed Limit (Should Get THROTTLED) ===');
  await sendAndWait('RATELIMIT user123 login', 'Request 4 (over limit)');
  await sendAndWait('RATELIMIT user123 login', 'Request 5 (over limit)');
  await sendAndWait('RLSTATS user123', 'Check remaining after throttle');

  // Test 6: Test different identifier
  console.log('=== Test 6: Different Identifier (Should Work Independently) ===');
  await sendAndWait('RLCONFIG 5 10 user456', 'Set limit for user456');
  await sendAndWait('RATELIMIT user456 order', 'Request from user456');
  await sendAndWait('RLSTATS user456', 'Check user456 remaining');

  // Test 7: Regular commands should NOT be rate limited
  console.log('=== Test 7: Regular Commands (NOT Rate Limited) ===');
  await sendAndWait('PING', 'Regular PING command');
  await sendAndWait('STATS', 'Regular STATS command');
  await sendAndWait('PING', 'Another PING command');

  console.log('========================================');
  console.log('Summary of All Responses:');
  console.log('========================================');
  responses.forEach((r, i) => console.log(`${(i + 1).toString().padStart(2)}. ${r}`));
  console.log('========================================');

  client.end();
  
  setTimeout(() => {
    console.log('\nTest Complete!');
    process.exit(0);
  }, 500);
}

testNewRateLimiter().catch(console.error);
