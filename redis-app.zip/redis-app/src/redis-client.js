const Redis = require('ioredis');
const config = require('../config');
const logger = require('./logger');

class RedisConnectionPool {
  constructor() {
    if (RedisConnectionPool.instance) {
      return RedisConnectionPool.instance;
    }

    this.availableConnections = [];  // Ready to use
    this.inUseConnections = new Set(); // Currently being used
    this.waitQueue = [];               // Requests waiting for connection
    this.totalConnections = 0;
    this.isInitialized = false;
    this.evictionTimer = null;
    
    RedisConnectionPool.instance = this;
  }

  /**
   * Validate Redis connectivity (hybrid startup)
   * Creates a temporary connection to test, then closes it
   */
  async validateConnectivity() {
    try {
      const testClient = new Redis({
        host: config.redis.host,
        port: config.redis.port,
        password: config.redis.password,
        db: config.redis.db,
        lazyConnect: true,
      });

      await testClient.connect();
      await testClient.ping();
      await testClient.quit();
      
      logger.redisEvent('Connectivity validated successfully');
      return true;
    } catch (error) {
      logger.error(`[REDIS] Connectivity validation failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Initialize the connection pool with minimum connections
   */
  async initialize() {
    if (this.isInitialized) {
      return;
    }

    logger.redisEvent('Initializing connection pool...');
    logger.redisEvent(`Pool config: min=${config.redis.pool.min}, max=${config.redis.pool.max}`);

    // Create minimum number of connections
    const promises = [];
    for (let i = 0; i < config.redis.pool.min; i++) {
      promises.push(this._createConnection());
    }

    try {
      await Promise.all(promises);
      this.isInitialized = true;
      logger.redisEvent(`Pool initialized with ${this.totalConnections} connections`);

      // Start eviction timer for idle connections
      this._startEvictionTimer();
    } catch (error) {
      logger.error(`[REDIS] Pool initialization failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Create a new Redis connection
   */
  async _createConnection() {
    try {
      const client = new Redis({
        host: config.redis.host,
        port: config.redis.port,
        password: config.redis.password,
        db: config.redis.db,
        retryStrategy: config.redis.retryStrategy,
        maxRetriesPerRequest: config.redis.maxRetriesPerRequest,
        lazyConnect: true,
      });

      // Set up event handlers
      client.on('error', (err) => {
        logger.error(`[REDIS] Connection error: ${err.message}`);
        this._removeConnection(client);
      });

      client.on('close', () => {
        this._removeConnection(client);
      });

      // Connect
      await client.connect();
      
      // Track connection metadata
      client._poolMetadata = {
        createdAt: Date.now(),
        lastUsedAt: Date.now(),
      };

      this.availableConnections.push(client);
      this.totalConnections++;
      
      logger.redisEvent(`Connection created (total: ${this.totalConnections})`);
      return client;
    } catch (error) {
      logger.error(`[REDIS] Failed to create connection: ${error.message}`);
      throw error;
    }
  }

  /**
   * Remove a connection from the pool
   */
  _removeConnection(client) {
    // Remove from available
    const availableIndex = this.availableConnections.indexOf(client);
    if (availableIndex > -1) {
      this.availableConnections.splice(availableIndex, 1);
    }

    // Remove from in-use
    this.inUseConnections.delete(client);

    this.totalConnections--;
    logger.redisEvent(`Connection removed (total: ${this.totalConnections})`);

    // Try to close gracefully
    try {
      if (client.status !== 'end') {
        client.disconnect();
      }
    } catch (error) {
      // Ignore errors during cleanup
    }

    // Maintain minimum connections
    if (this.isInitialized && this.totalConnections < config.redis.pool.min) {
      this._createConnection().catch(err => {
        logger.error(`[REDIS] Failed to replace connection: ${err.message}`);
      });
    }
  }

  /**
   * Acquire a connection from the pool
   */
  async acquireConnection() {
    // Initialize pool on first use (lazy initialization)
    if (!this.isInitialized) {
      await this.initialize();
    }

    // Try to get available connection
    if (this.availableConnections.length > 0) {
      const connection = this.availableConnections.shift();
      this.inUseConnections.add(connection);
      connection._poolMetadata.lastUsedAt = Date.now();
      return connection;
    }

    // Create new connection if under max
    if (this.totalConnections < config.redis.pool.max) {
      const connection = await this._createConnection();
      // Move from available to in-use
      const index = this.availableConnections.indexOf(connection);
      if (index > -1) {
        this.availableConnections.splice(index, 1);
      }
      this.inUseConnections.add(connection);
      connection._poolMetadata.lastUsedAt = Date.now();
      return connection;
    }

    // Pool exhausted, wait in queue
    logger.redisEvent(`Pool exhausted, queuing request (waiting: ${this.waitQueue.length + 1})`);
    
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        // Remove from queue
        const index = this.waitQueue.indexOf(request);
        if (index > -1) {
          this.waitQueue.splice(index, 1);
        }
        reject(new Error('Pool exhausted, timeout waiting for connection'));
      }, config.redis.pool.acquireTimeout);

      const request = { resolve, reject, timeout };
      this.waitQueue.push(request);
    });
  }

  /**
   * Release a connection back to the pool
   */
  releaseConnection(connection) {
    if (!connection) {
      return;
    }

    // Remove from in-use
    this.inUseConnections.delete(connection);
    
    // Check if connection is still healthy
    if (connection.status !== 'ready') {
      logger.redisEvent('Released connection is unhealthy, removing');
      this._removeConnection(connection);
      return;
    }

    // Update metadata
    connection._poolMetadata.lastUsedAt = Date.now();

    // Process wait queue if any
    if (this.waitQueue.length > 0) {
      const request = this.waitQueue.shift();
      clearTimeout(request.timeout);
      this.inUseConnections.add(connection);
      request.resolve(connection);
      logger.redisEvent(`Processed queued request (waiting: ${this.waitQueue.length})`);
      return;
    }

    // Add back to available connections
    this.availableConnections.push(connection);
  }

  /**
   * Execute a command with automatic acquire/release
   */
  async _executeWithConnection(fn) {
    const connection = await this.acquireConnection();
    try {
      const result = await fn(connection);
      this.releaseConnection(connection);
      return result;
    } catch (error) {
      this.releaseConnection(connection);
      throw error;
    }
  }

  /**
   * Check if Redis is connected and responsive
   */
  async ping() {
    return this._executeWithConnection(async (connection) => {
      return await connection.ping();
    });
  }

  /**
   * Get the total number of keys in the database
   */
  async getTotalKeys() {
    return this._executeWithConnection(async (connection) => {
      return await connection.dbsize();
    });
  }

  /**
   * Count keys matching a pattern
   * @param {string} pattern - The pattern to match
   * @param {string} type - 'PREFIX' or 'WILDCARD'
   */
  async countPattern(pattern, type = 'PREFIX') {
    return this._executeWithConnection(async (connection) => {
      let searchPattern = pattern;
      
      // If type is PREFIX and pattern doesn't end with *, add it
      if (type === 'PREFIX' && !pattern.endsWith('*')) {
        searchPattern = pattern + '*';
      }
      // For WILDCARD, use the pattern as-is

      // Use SCAN for safer pattern matching (doesn't block Redis)
      let count = 0;
      let cursor = '0';
      
      do {
        const [nextCursor, keys] = await connection.scan(
          cursor,
          'MATCH',
          searchPattern,
          'COUNT',
          100
        );
        cursor = nextCursor;
        count += keys.length;
      } while (cursor !== '0');

      return count;
    });
  }

  /**
   * Start eviction timer to clean up idle connections
   */
  _startEvictionTimer() {
    if (this.evictionTimer) {
      clearInterval(this.evictionTimer);
    }

    this.evictionTimer = setInterval(() => {
      this._evictIdleConnections();
    }, config.redis.pool.evictionRunInterval);
  }

  /**
   * Evict idle connections (keep above minimum)
   */
  _evictIdleConnections() {
    const now = Date.now();
    const idleThreshold = now - config.redis.pool.idleTimeout;

    let evicted = 0;
    const connectionsToEvict = [];

    // Check available connections for idle timeout
    for (const connection of this.availableConnections) {
      if (this.totalConnections <= config.redis.pool.min) {
        break; // Keep minimum connections
      }

      if (connection._poolMetadata.lastUsedAt < idleThreshold) {
        connectionsToEvict.push(connection);
      }
    }

    // Evict idle connections
    for (const connection of connectionsToEvict) {
      this._removeConnection(connection);
      evicted++;
    }

    if (evicted > 0) {
      logger.redisEvent(`Evicted ${evicted} idle connections (total: ${this.totalConnections})`);
    }
  }

  /**
   * Get pool statistics
   */
  getPoolStats() {
    return {
      available: this.availableConnections.length,
      inUse: this.inUseConnections.size,
      total: this.totalConnections,
      waiting: this.waitQueue.length,
      min: config.redis.pool.min,
      max: config.redis.pool.max,
      initialized: this.isInitialized,
    };
  }

  /**
   * Gracefully shutdown the connection pool
   */
  async shutdownPool() {
    logger.redisEvent('Shutting down connection pool...');
    
    // Stop eviction timer
    if (this.evictionTimer) {
      clearInterval(this.evictionTimer);
      this.evictionTimer = null;
    }

    // Reject all waiting requests
    for (const request of this.waitQueue) {
      clearTimeout(request.timeout);
      request.reject(new Error('Pool shutting down'));
    }
    this.waitQueue = [];

    // Close all connections
    const allConnections = [
      ...this.availableConnections,
      ...Array.from(this.inUseConnections),
    ];

    const closePromises = allConnections.map(async (connection) => {
      try {
        await connection.quit();
      } catch (error) {
        connection.disconnect();
      }
    });

    await Promise.allSettled(closePromises);

    this.availableConnections = [];
    this.inUseConnections.clear();
    this.totalConnections = 0;
    this.isInitialized = false;

    logger.redisEvent('Connection pool shut down');
  }

  /**
   * Check if pool is ready
   */
  isReady() {
    return this.isInitialized && this.totalConnections > 0;
  }
}

// Export singleton instance
module.exports = new RedisConnectionPool();
