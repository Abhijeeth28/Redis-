const redisClient = require('../redis-client');
const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * STATS command handler
 * Returns the total number of keys in Redis database
 * 
 * Request: STATS\n
 * Response: TOTAL_KEYS:<count>\n
 * Error: ERROR:Failed to retrieve stats\n
 */
async function statsCommand(clientId, args) {
  try {
    // Validate no arguments
    const validation = Protocol.validateCommand('STATS', args, { 
      minArgs: 0, 
      maxArgs: 0 
    });

    if (!validation.valid) {
      return {
        response: Protocol.formatError(validation.error),
        closeConnection: false,
      };
    }

    // Get total key count from Redis
    const count = await redisClient.getTotalKeys();
    
    return {
      response: Protocol.formatResponse(`TOTAL_KEYS:${count}`),
      closeConnection: false,
    };
  } catch (error) {
    logger.commandError(clientId, error);
    return {
      response: Protocol.formatError(`Failed to retrieve stats: ${error.message}`),
      closeConnection: false,
    };
  }
}

module.exports = statsCommand;
