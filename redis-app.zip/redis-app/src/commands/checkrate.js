const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * CHECKRATE command handler
 * Check current rate limit status for an identifier
 * 
 * Request: CHECKRATE [identifier]\n
 * Response: RATELIMIT:current=<n> limit=<n> remaining=<n> window=<n>s\n
 * 
 * If no identifier is provided, uses 'default'
 */
async function checkrateCommand(clientId, args, rateLimiter) {
  // Validate arguments (0 or 1 arg)
  const validation = Protocol.validateCommand('CHECKRATE', args, { 
    minArgs: 0, 
    maxArgs: 1 
  });

  if (!validation.valid) {
    return {
      response: Protocol.formatError(validation.error),
      closeConnection: false,
    };
  }

  const identifier = args[0] || 'default';
  const status = await rateLimiter.getRateLimitStatus(identifier);
  
  const statusStr = `current=${status.currentCount} limit=${status.limit} ` +
                    `remaining=${status.remaining} window=${status.windowSeconds}s`;
  
  return {
    response: Protocol.formatResponse(`RATELIMIT:${statusStr}`),
    closeConnection: false,
  };
}

module.exports = checkrateCommand;
