const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * RATELIMIT command handler
 * Check if an identifier is allowed to perform an action based on rate limits
 * 
 * Request: RATELIMIT <identifier> <action>\n
 * Response: ALLOWED\n or THROTTLED\n
 * 
 * Examples:
 * - RATELIMIT user123 login     → Check if user123 can login
 * - RATELIMIT api:key:abc order → Check if api:key:abc can place order
 * - RATELIMIT 192.168.1.1 request → Check if IP can make request
 */
async function ratelimitCommand(clientId, args, rateLimiter) {
  // Validate arguments
  const validation = Protocol.validateCommand('RATELIMIT', args, { 
    minArgs: 2, 
    maxArgs: 2 
  });

  if (!validation.valid) {
    return {
      response: Protocol.formatError(validation.error),
      closeConnection: false,
    };
  }

  const identifier = args[0];
  const action = args[1];

  try {
    // Check rate limit for this identifier
    const rateLimitResult = await rateLimiter.checkRateLimit(identifier);
    
    if (rateLimitResult.allowed) {
      logger.info(`[${clientId}] RATELIMIT ${identifier} ${action}: ALLOWED (${rateLimitResult.remaining} remaining)`);
      return {
        response: Protocol.formatResponse('ALLOWED'),
        closeConnection: false,
      };
    } else {
      logger.info(`[${clientId}] RATELIMIT ${identifier} ${action}: THROTTLED (retry in ${rateLimitResult.retryAfter}s)`);
      return {
        response: Protocol.formatResponse('THROTTLED'),
        closeConnection: false,
      };
    }
  } catch (error) {
    logger.error(`[${clientId}] RATELIMIT check failed: ${error.message}`);
    return {
      response: Protocol.formatError('Rate limit check failed'),
      closeConnection: false,
    };
  }
}

module.exports = ratelimitCommand;
