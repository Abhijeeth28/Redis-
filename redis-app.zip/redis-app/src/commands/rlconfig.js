const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * RLCONFIG command handler
 * Configure rate limit settings (applies to all identifiers by default)
 * 
 * Request: RLCONFIG <limit> <window_seconds> [identifier]\n
 * Response: RATELIMIT:SET limit=<n> window=<n>s [for <identifier>]\n
 * 
 * Examples:
 * - RLCONFIG 50 30              → Set default to 50 requests per 30 seconds
 * - RLCONFIG 1000 60            → Set default to 1000 requests per 60 seconds
 * - RLCONFIG 10 5 user123       → Set user123 to 10 requests per 5 seconds
 */
async function rlconfigCommand(clientId, args, rateLimiter) {
  // Validate arguments (2 or 3 args: limit, window, [identifier])
  const validation = Protocol.validateCommand('RLCONFIG', args, { 
    minArgs: 2, 
    maxArgs: 3 
  });

  if (!validation.valid) {
    return {
      response: Protocol.formatError(validation.error),
      closeConnection: false,
    };
  }

  const limit = parseInt(args[0], 10);
  const windowSeconds = parseInt(args[1], 10);
  const identifier = args[2] || 'default';

  // Validate numeric values
  if (isNaN(limit) || limit <= 0) {
    return {
      response: Protocol.formatError('Limit must be a positive number'),
      closeConnection: false,
    };
  }

  if (isNaN(windowSeconds) || windowSeconds <= 0) {
    return {
      response: Protocol.formatError('Window must be a positive number of seconds'),
      closeConnection: false,
    };
  }

  // Set rate limit for identifier
  rateLimiter.setClientLimit(identifier, limit, windowSeconds);
  
  const identifierMsg = identifier === 'default' ? '' : ` for ${identifier}`;
  return {
    response: Protocol.formatResponse(`RATELIMIT:SET limit=${limit} window=${windowSeconds}s${identifierMsg}`),
    closeConnection: false,
  };
}

module.exports = rlconfigCommand;
