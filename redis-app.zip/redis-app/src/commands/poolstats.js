const redisClient = require('../redis-client');
const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * POOLSTATS command handler
 * Returns connection pool statistics
 * 
 * Request: POOLSTATS\n
 * Response: POOL:available=<n>,inUse=<n>,total=<n>,waiting=<n>,min=<n>,max=<n>\n
 */
async function poolstatsCommand(clientId, args) {
  try {
    // Validate no arguments
    const validation = Protocol.validateCommand('POOLSTATS', args, { 
      minArgs: 0, 
      maxArgs: 0 
    });

    if (!validation.valid) {
      return {
        response: Protocol.formatError(validation.error),
        closeConnection: false,
      };
    }

    // Get pool statistics
    const stats = redisClient.getPoolStats();
    
    const statsStr = `available=${stats.available},inUse=${stats.inUse},` +
                     `total=${stats.total},waiting=${stats.waiting},` +
                     `min=${stats.min},max=${stats.max}`;
    
    return {
      response: Protocol.formatResponse(`POOL:${statsStr}`),
      closeConnection: false,
    };
  } catch (error) {
    logger.commandError(clientId, error);
    return {
      response: Protocol.formatError(`Failed to get pool stats: ${error.message}`),
      closeConnection: false,
    };
  }
}

module.exports = poolstatsCommand;
