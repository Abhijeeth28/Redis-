const redisClient = require('../redis-client');
const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * PING command handler
 * Checks if Redis is connected and responsive
 * 
 * Request: PING\n
 * Response: PONG\n (after successful redis.ping())
 * Error: ERROR:Redis connection failed\n (then close connection)
 */
async function pingCommand(clientId, args) {
  try {
    // Validate no arguments
    const validation = Protocol.validateCommand('PING', args, { 
      minArgs: 0, 
      maxArgs: 0 
    });

    if (!validation.valid) {
      return {
        response: Protocol.formatError(validation.error),
        closeConnection: false,
      };
    }

    // Ping Redis
    await redisClient.ping();
    
    return {
      response: Protocol.formatResponse('PONG'),
      closeConnection: false,
    };
  } catch (error) {
    logger.commandError(clientId, error);
    return {
      response: Protocol.formatError(`Redis connection failed: ${error.message}`),
      closeConnection: true, // Close connection on Redis failure
    };
  }
}

module.exports = pingCommand;
