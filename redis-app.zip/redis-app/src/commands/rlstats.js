const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * RLSTATS command handler
 * Get remaining rate limit count for an identifier
 * 
 * Request: RLSTATS <identifier>\n
 * Response: <remaining_count>\n
 * 
 * Examples:
 * - RLSTATS user123     → Returns remaining requests for user123
 * - RLSTATS api:key:abc → Returns remaining requests for api:key:abc
 * - RLSTATS 192.168.1.1 → Returns remaining requests for IP
 */
async function rlstatsCommand(clientId, args, rateLimiter) {
  // Validate arguments
  const validation = Protocol.validateCommand('RLSTATS', args, { 
    minArgs: 1, 
    maxArgs: 1 
  });

  if (!validation.valid) {
    return {
      response: Protocol.formatError(validation.error),
      closeConnection: false,
    };
  }

  const identifier = args[0];

  try {
    const status = await rateLimiter.getRateLimitStatus(identifier);
    
    logger.info(`[${clientId}] RLSTATS ${identifier}: ${status.remaining} remaining`);
    
    return {
      response: Protocol.formatResponse(status.remaining.toString()),
      closeConnection: false,
    };
  } catch (error) {
    logger.error(`[${clientId}] RLSTATS check failed: ${error.message}`);
    return {
      response: Protocol.formatError('Failed to get rate limit stats'),
      closeConnection: false,
    };
  }
}

module.exports = rlstatsCommand;
