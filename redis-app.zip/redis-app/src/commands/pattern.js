const redisClient = require('../redis-client');
const Protocol = require('../protocol');
const logger = require('../logger');

/**
 * PATTERN command handler
 * Counts keys matching a given pattern
 * 
 * Request: PATTERN <pattern> [TYPE]
 * Response: COUNT:<number>\n
 * 
 * Supported formats:
 * - PATTERN user: PREFIX        # Prefix match: user:*
 * - PATTERN user:* WILDCARD     # Wildcard match: user:*
 * - PATTERN user:              # Default to prefix if no type specified
 */
async function patternCommand(clientId, args) {
  try {
    // Validate arguments: need at least pattern, optionally type
    const validation = Protocol.validateCommand('PATTERN', args, { 
      minArgs: 1, 
      maxArgs: 2 
    });

    if (!validation.valid) {
      return {
        response: Protocol.formatError(validation.error),
        closeConnection: false,
      };
    }

    const pattern = args[0];
    const type = args[1] ? args[1].toUpperCase() : 'PREFIX';

    // Validate type
    if (type !== 'PREFIX' && type !== 'WILDCARD') {
      return {
        response: Protocol.formatError('Invalid type. Must be PREFIX or WILDCARD'),
        closeConnection: false,
      };
    }

    // Count keys matching the pattern
    const count = await redisClient.countPattern(pattern, type);
    
    return {
      response: Protocol.formatResponse(`COUNT:${count}`),
      closeConnection: false,
    };
  } catch (error) {
    logger.commandError(clientId, error);
    return {
      response: Protocol.formatError(`Failed to count pattern: ${error.message}`),
      closeConnection: false,
    };
  }
}

module.exports = patternCommand;
