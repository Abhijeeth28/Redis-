const logger = require('./logger');

/**
 * Protocol handler for parsing commands and formatting responses
 */
class Protocol {
  /**
   * Parse a line into command and arguments
   * @param {string} line - The command line to parse
   * @returns {object} - { command, args }
   */
  static parseLine(line) {
    const trimmed = line.trim();
    if (!trimmed) {
      return null;
    }

    const parts = trimmed.split(/\s+/);
    const command = parts[0].toUpperCase();
    const args = parts.slice(1);

    return { command, args };
  }

  /**
   * Process buffer data and extract complete lines
   * @param {string} buffer - The current buffer
   * @param {string} newData - New data to add to buffer
   * @returns {object} - { lines: [], remainingBuffer: string }
   */
  static processBuffer(buffer, newData) {
    const combined = buffer + newData;
    const lines = combined.split('\n');
    
    // The last element might be incomplete, keep it in buffer
    const remainingBuffer = lines.pop() || '';
    
    // Filter out empty lines
    const validLines = lines.filter(line => line.trim().length > 0);

    return {
      lines: validLines,
      remainingBuffer,
    };
  }

  /**
   * Format a success response
   * @param {string} message - The response message
   * @returns {string} - Formatted response with newline
   */
  static formatResponse(message) {
    return `${message}\n`;
  }

  /**
   * Format an error response
   * @param {string} message - The error message
   * @returns {string} - Formatted error response
   */
  static formatError(message) {
    return `ERROR:${message}\n`;
  }

  /**
   * Validate command structure
   * @param {string} command - The command name
   * @param {array} args - The command arguments
   * @param {object} requirements - { minArgs, maxArgs }
   * @returns {object} - { valid: boolean, error: string }
   */
  static validateCommand(command, args, requirements) {
    const { minArgs = 0, maxArgs = Infinity } = requirements;

    if (args.length < minArgs) {
      return {
        valid: false,
        error: `Invalid arguments for ${command}`,
      };
    }

    if (args.length > maxArgs) {
      return {
        valid: false,
        error: `Too many arguments for ${command}`,
      };
    }

    return { valid: true };
  }
}

module.exports = Protocol;
