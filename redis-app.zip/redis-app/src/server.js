const net = require('net');
const config = require('../config');
const logger = require('./logger');
const Protocol = require('./protocol');
const RateLimiter = require('./rate-limiter');
const redisClient = require('./redis-client');

// Import command handlers
const pingCommand = require('./commands/ping');
const statsCommand = require('./commands/stats');
const patternCommand = require('./commands/pattern');
const poolstatsCommand = require('./commands/poolstats');
const rlconfigCommand = require('./commands/rlconfig');
const checkrateCommand = require('./commands/checkrate');
const ratelimitCommand = require('./commands/ratelimit');
const rlstatsCommand = require('./commands/rlstats');

// Command registry
const COMMANDS = {
  PING: pingCommand,
  STATS: statsCommand,
  PATTERN: patternCommand,
  POOLSTATS: poolstatsCommand,
  RLCONFIG: rlconfigCommand,
  CHECKRATE: checkrateCommand,
  RATELIMIT: ratelimitCommand,
  RLSTATS: rlstatsCommand,
};

class TCPServer {
  constructor() {
    this.server = null;
    this.connections = new Map(); // clientId -> { socket, buffer, ip, port, connectedAt }
    this.nextClientId = 1;
    this.isShuttingDown = false;
    this.rateLimiter = new RateLimiter(redisClient);
  }

  /**
   * Start the TCP server
   */
  start() {
    return new Promise((resolve, reject) => {
      this.server = net.createServer((socket) => {
        this.handleConnection(socket);
      });

      this.server.on('error', (error) => {
        logger.error(`[SERVER] Error: ${error.message}`);
        reject(error);
      });

      this.server.listen(config.tcp.port, config.tcp.host, () => {
        logger.serverEvent(`Listening on ${config.tcp.host}:${config.tcp.port}`);
        logger.serverEvent(`Max connections: ${config.tcp.maxConnections}`);
        resolve();
      });
    });
  }

  /**
   * Handle new client connection
   */
  handleConnection(socket) {
    // Check if server is shutting down
    if (this.isShuttingDown) {
      socket.write(Protocol.formatError('Server is shutting down'));
      socket.end();
      return;
    }

    // Check connection limit
    if (this.connections.size >= config.tcp.maxConnections) {
      logger.serverEvent(`Connection limit reached (${this.connections.size}/${config.tcp.maxConnections})`);
      socket.write(Protocol.formatError('Server at capacity'));
      socket.end();
      return;
    }

    // Assign unique client ID
    const clientId = this.nextClientId++;
    const clientInfo = {
      socket,
      buffer: '',
      ip: socket.remoteAddress,
      port: socket.remotePort,
      connectedAt: new Date(),
    };

    this.connections.set(clientId, clientInfo);
    logger.connection(clientId, clientInfo.ip, clientInfo.port);
    logger.serverEvent(`Active connections: ${this.connections.size}`);

    // Set up socket event handlers
    socket.on('data', (data) => {
      this.handleData(clientId, data);
    });

    socket.on('end', () => {
      this.handleDisconnect(clientId, 'client ended connection');
    });

    socket.on('error', (error) => {
      logger.commandError(clientId, error);
      this.handleDisconnect(clientId, `error: ${error.message}`);
    });

    socket.on('close', () => {
      this.handleDisconnect(clientId, 'socket closed');
    });
  }

  /**
   * Handle incoming data from a client
   */
  async handleData(clientId, data) {
    const clientInfo = this.connections.get(clientId);
    if (!clientInfo) {
      return;
    }

    try {
      const dataStr = data.toString('utf8');
      
      // Process buffer and extract complete lines
      const { lines, remainingBuffer } = Protocol.processBuffer(
        clientInfo.buffer,
        dataStr
      );

      // Update buffer
      clientInfo.buffer = remainingBuffer;

      // Process each complete line
      for (const line of lines) {
        await this.processCommand(clientId, line);
      }
    } catch (error) {
      logger.commandError(clientId, error);
      clientInfo.socket.write(Protocol.formatError('Internal server error'));
    }
  }

  /**
   * Process a single command
   */
  async processCommand(clientId, line) {
    const clientInfo = this.connections.get(clientId);
    if (!clientInfo) {
      return;
    }

    // Parse the command line
    const parsed = Protocol.parseLine(line);
    if (!parsed) {
      return; // Empty line, ignore
    }

    const { command, args } = parsed;
    logger.command(clientId, command, args.join(' '));

    // Check if command exists
    const handler = COMMANDS[command];
    if (!handler) {
      const response = Protocol.formatError(`Unknown command: ${command}`);
      clientInfo.socket.write(response);
      return;
    }

    try {
      // Execute command (pass rateLimiter for rate limit related commands)
      const rateLimitCommands = ['RLCONFIG', 'CHECKRATE', 'RATELIMIT', 'RLSTATS'];
      const result = rateLimitCommands.includes(command)
        ? await handler(clientId, args, this.rateLimiter)
        : await handler(clientId, args);
      
      // Send response
      if (result.response) {
        clientInfo.socket.write(result.response);
      }

      // Close connection if requested (e.g., on critical errors)
      if (result.closeConnection) {
        logger.disconnection(clientId, 'command requested closure');
        clientInfo.socket.end();
      }
    } catch (error) {
      logger.commandError(clientId, error);
      const response = Protocol.formatError('Command execution failed');
      clientInfo.socket.write(response);
    }
  }

  /**
   * Handle client disconnection
   */
  handleDisconnect(clientId, reason) {
    const clientInfo = this.connections.get(clientId);
    if (!clientInfo) {
      return; // Already disconnected
    }

    logger.disconnection(clientId, reason);
    
    // Clean up rate limit data
    this.rateLimiter.clearRateLimit(clientId).catch(err => {
      logger.error(`Failed to clear rate limit for ${clientId}: ${err.message}`);
    });
    
    this.connections.delete(clientId);
    logger.serverEvent(`Active connections: ${this.connections.size}`);
  }

  /**
   * Get current connection count
   */
  getConnectionCount() {
    return this.connections.size;
  }

  /**
   * Gracefully shutdown the server
   */
  async shutdown() {
    this.isShuttingDown = true;
    logger.serverEvent('Initiating graceful shutdown...');
    logger.serverEvent(`Active connections: ${this.connections.size}`);

    // Stop accepting new connections
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          logger.serverEvent('Server stopped accepting connections');
        });
      }

      // Notify all active clients
      for (const [clientId, clientInfo] of this.connections) {
        try {
          clientInfo.socket.write(Protocol.formatError('Server shutting down'));
          clientInfo.socket.end();
        } catch (error) {
          // Ignore errors during shutdown
        }
      }

      // Wait for connections to close or timeout
      const shutdownTimeout = setTimeout(() => {
        logger.serverEvent('Shutdown timeout reached, forcing close');
        // Force close remaining connections
        for (const [clientId, clientInfo] of this.connections) {
          try {
            clientInfo.socket.destroy();
          } catch (error) {
            // Ignore
          }
        }
        this.connections.clear();
        resolve();
      }, config.shutdown.gracePeriodMs);

      // Check periodically if all connections are closed
      const checkInterval = setInterval(() => {
        if (this.connections.size === 0) {
          clearInterval(checkInterval);
          clearTimeout(shutdownTimeout);
          logger.serverEvent('All connections closed gracefully');
          resolve();
        }
      }, 100);
    });
  }
}

module.exports = TCPServer;
