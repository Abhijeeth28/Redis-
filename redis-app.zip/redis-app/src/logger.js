const winston = require('winston');
const path = require('path');
const fs = require('fs');
const config = require('../config');

// Create logs directory if it doesn't exist
const logDir = config.logging.directory;
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// Define log format
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, stack }) => {
    if (stack) {
      return `${timestamp} [${level.toUpperCase()}]: ${message}\n${stack}`;
    }
    return `${timestamp} [${level.toUpperCase()}]: ${message}`;
  })
);

// Create logger instance
const logger = winston.createLogger({
  level: config.logging.level,
  format: logFormat,
  transports: [
    // Console transport with colors
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.printf(({ timestamp, level, message }) => {
          return `${timestamp} [${level}]: ${message}`;
        })
      ),
    }),
    // File transport for all logs
    new winston.transports.File({
      filename: path.join(logDir, 'server.log'),
      maxsize: config.logging.maxSize,
      maxFiles: config.logging.maxFiles,
    }),
    // File transport for errors only
    new winston.transports.File({
      filename: path.join(logDir, 'error.log'),
      level: 'error',
      maxsize: config.logging.maxSize,
      maxFiles: config.logging.maxFiles,
    }),
  ],
});

// Add helper methods for consistent logging
logger.connection = (clientId, ip, port) => {
  logger.info(`Client [${clientId}] connected from ${ip}:${port}`);
};

logger.disconnection = (clientId, reason = 'client disconnect') => {
  logger.info(`Client [${clientId}] disconnected (${reason})`);
};

logger.command = (clientId, command, args = '') => {
  const argStr = args ? ` ${args}` : '';
  logger.info(`[${clientId}] Command: ${command}${argStr}`);
};

logger.commandError = (clientId, error) => {
  logger.error(`[${clientId}] Error: ${error.message || error}`);
};

logger.serverEvent = (message) => {
  logger.info(`[SERVER] ${message}`);
};

logger.redisEvent = (message) => {
  logger.info(`[REDIS] ${message}`);
};

logger.poolStats = (stats) => {
  logger.info(
    `[POOL] Stats: total=${stats.total}, available=${stats.available}, ` +
    `inUse=${stats.inUse}, waiting=${stats.waiting}, ` +
    `min=${stats.min}, max=${stats.max}`
  );
};

module.exports = logger;
