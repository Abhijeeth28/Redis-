const config = require('../config');
const logger = require('./logger');

/**
 * Rate Limiter using sliding window algorithm
 * Uses Redis sorted sets to track request timestamps
 */
class RateLimiter {
  constructor(redisPool) {
    this.redisPool = redisPool;
    this.clientLimits = new Map(); // clientId → {limit, windowSeconds}
  }

  /**
   * Configure rate limit for a specific client
   * @param {string} clientId - The client identifier
   * @param {number} limit - Maximum requests allowed in window
   * @param {number} windowSeconds - Time window in seconds
   */
  setClientLimit(clientId, limit, windowSeconds) {
    this.clientLimits.set(clientId, { limit, windowSeconds });
    logger.info(`[${clientId}] Rate limit configured: ${limit} requests per ${windowSeconds}s`);
  }

  /**
   * Get client's rate limit config (or default)
   * @param {string} clientId - The client identifier
   * @returns {object} - { limit, windowSeconds }
   */
  getClientLimit(clientId) {
    // Check if client has a specific limit
    if (this.clientLimits.has(clientId)) {
      return this.clientLimits.get(clientId);
    }
    
    // Check if a custom default limit has been set
    if (this.clientLimits.has('default')) {
      return this.clientLimits.get('default');
    }
    
    // Fall back to config default
    return {
      limit: config.rateLimiting.default.limit,
      windowSeconds: config.rateLimiting.default.windowSeconds,
    };
  }

  /**
   * Check if request is allowed using sliding window algorithm
   * @param {string} clientId - The client identifier
   * @returns {Promise<object>} - Result with allowed status and metadata
   */
  async checkRateLimit(clientId) {
    const { limit, windowSeconds } = this.getClientLimit(clientId);
    const now = Date.now();
    const windowStart = now - (windowSeconds * 1000);
    
    // Redis key for this client
    const key = `${config.rateLimiting.redisKeyPrefix}${clientId}`;
    
    // Use Redis sorted set for sliding window
    // Score = timestamp, Member = unique request ID
    
    return await this.redisPool._executeWithConnection(async (conn) => {
      // 1. Remove old entries outside window
      await conn.zremrangebyscore(key, 0, windowStart);
      
      // 2. Count current requests in window
      const currentCount = await conn.zcard(key);
      
      // 3. Check if under limit
      if (currentCount >= limit) {
        // Get oldest timestamp to calculate retry-after
        const oldest = await conn.zrange(key, 0, 0, 'WITHSCORES');
        const retryAfter = oldest.length > 0 
          ? Math.ceil((parseFloat(oldest[1]) + (windowSeconds * 1000) - now) / 1000)
          : windowSeconds;
          
        return {
          allowed: false,
          currentCount,
          limit,
          windowSeconds,
          retryAfter,
        };
      }
      
      // 4. Add current request
      const requestId = `${now}-${Math.random()}`;
      await conn.zadd(key, now, requestId);
      
      // 5. Set expiry on key (cleanup)
      await conn.expire(key, windowSeconds);
      
      return {
        allowed: true,
        currentCount: currentCount + 1,
        limit,
        windowSeconds,
        remaining: limit - currentCount - 1,
      };
    });
  }

  /**
   * Get current rate limit status without making a request
   * @param {string} clientId - The client identifier
   * @returns {Promise<object>} - Current status
   */
  async getRateLimitStatus(clientId) {
    const { limit, windowSeconds } = this.getClientLimit(clientId);
    const now = Date.now();
    const windowStart = now - (windowSeconds * 1000);
    const key = `${config.rateLimiting.redisKeyPrefix}${clientId}`;
    
    return await this.redisPool._executeWithConnection(async (conn) => {
      // Remove old entries
      await conn.zremrangebyscore(key, 0, windowStart);
      
      // Count current requests
      const currentCount = await conn.zcard(key);
      
      return {
        currentCount,
        limit,
        remaining: Math.max(0, limit - currentCount),
        windowSeconds,
        resetsIn: windowSeconds, // Always resets based on sliding window
      };
    });
  }

  /**
   * Clear rate limit for a client
   * @param {string} clientId - The client identifier
   */
  async clearRateLimit(clientId) {
    const key = `${config.rateLimiting.redisKeyPrefix}${clientId}`;
    await this.redisPool._executeWithConnection(async (conn) => {
      await conn.del(key);
    });
    this.clientLimits.delete(clientId);
    logger.info(`[${clientId}] Rate limit cleared`);
  }
}

module.exports = RateLimiter;
