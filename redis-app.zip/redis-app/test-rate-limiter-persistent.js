const net = require('net');

async function testRateLimiter() {
  console.log('========================================');
  console.log('Testing Rate Limiter (Single Connection)');
  console.log('========================================\n');

  const client = net.createConnection({ port: 9736, host: 'localhost' });
  
  let buffer = '';
  const responses = [];
  
  client.on('data', (data) => {
    buffer += data.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop(); // Keep incomplete line
    
    for (const line of lines) {
      if (line.trim()) {
        responses.push(line.trim());
      }
    }
  });

  await new Promise(resolve => client.once('connect', resolve));
  console.log('Connected to server\n');

  // Helper to send command and wait for response
  async function sendAndWait(cmd, label) {
    const before = responses.length;
    client.write(cmd + '\n');
    console.log(`${label}: ${cmd}`);
    
    // Wait for response
    await new Promise(resolve => {
      const check = setInterval(() => {
        if (responses.length > before) {
          clearInterval(check);
          console.log(`  Response: ${responses[responses.length - 1]}\n`);
          resolve();
        }
      }, 50);
    });
  }

  // Test 1: Set rate limit to 3 requests per 10 seconds
  console.log('Test 1: Setting rate limit to 3 requests per 10 seconds');
  await sendAndWait('RLCONFIG 3 10', 'Command');

  // Test 2: Send 3 requests (should all succeed)
  console.log('Test 2: Sending 3 PING requests (should all succeed)');
  await sendAndWait('PING', 'Request 1');
  await sendAndWait('PING', 'Request 2');
  await sendAndWait('PING', 'Request 3');

  // Test 3: Check status after 3 requests
  console.log('Test 3: Checking rate limit status');
  await sendAndWait('CHECKRATE', 'Command');

  // Test 4: Send 2 more requests (should be rate limited)
  console.log('Test 4: Sending 2 more PING requests (SHOULD BE RATE LIMITED)');
  await sendAndWait('PING', 'Request 4');
  await sendAndWait('PING', 'Request 5');

  // Test 5: Check status after being rate limited
  console.log('Test 5: Checking rate limit status after exceeding');
  await sendAndWait('CHECKRATE', 'Command');

  console.log('========================================');
  console.log('All responses:');
  responses.forEach((r, i) => console.log(`${i + 1}. ${r}`));
  console.log('========================================');

  client.end();
  
  setTimeout(() => {
    console.log('\nTest Complete!');
    process.exit(0);
  }, 500);
}

testRateLimiter().catch(console.error);
